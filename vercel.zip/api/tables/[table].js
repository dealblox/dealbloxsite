/**
 * DEAL BLOX — Vercel Function: /api/tables/[table]
 *
 * Faz ponte entre o frontend (fetch('tables/xxx')) e o Supabase.
 * Suporta GET, POST, PATCH, PUT, DELETE.
 *
 * Variáveis de ambiente necessárias no Vercel:
 *   SUPABASE_URL  → URL do projeto Supabase
 *   SUPABASE_KEY  → chave service_role
 */

const ALLOWED_ORIGINS = [
  'https://dealblox.com.br',
  'https://www.dealblox.com.br',
  'https://dealbloxsite.vercel.app',
  'http://localhost:3000',
  'http://localhost:5500',
  'http://127.0.0.1:5500',
  'http://localhost:8080',
];

const ALLOWED_TABLES = ['products', 'users', 'access_logs', 'orders', 'messages', 'account_stock'];

function formatFilterValue(value) {
  const stringValue = String(value);
  if (/^(eq|neq|gt|gte|lt|lte|like|ilike|is|in|cs|cd|ov|fts|plfts|phfts|wfts|not)\./.test(stringValue)) {
    return stringValue;
  }
  return `eq.${encodeURIComponent(stringValue)}`;
}

export default async function handler(req, res) {
  const origin = req.headers.origin || '';
  const isLocal = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);
  const corsOrigin = ALLOWED_ORIGINS.includes(origin) || isLocal ? origin : ALLOWED_ORIGINS[0];

  res.setHeader('Access-Control-Allow-Origin', corsOrigin);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Vary', 'Origin');

  if (req.method === 'OPTIONS') return res.status(200).end();

  let rawTable = req.query.table || '';
  let urlId = null;

  if (rawTable.includes('/')) {
    const parts = rawTable.split('/');
    rawTable = parts[0];
    urlId = parts[1] || null;
  }

  const table = rawTable;
  if (!table || !ALLOWED_TABLES.includes(table)) {
    return res.status(400).json({ error: `Tabela '${table}' não permitida` });
  }

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_KEY;

  if (!SUPABASE_URL || !SUPABASE_KEY) {
    console.error('[tables] SUPABASE_URL ou SUPABASE_KEY não configurados');
    return res.status(500).json({ error: 'Servidor não configurado (env vars ausentes)' });
  }

  const baseUrl = `${SUPABASE_URL}/rest/v1/${table}`;
  const headers = {
    apikey: SUPABASE_KEY,
    Authorization: `Bearer ${SUPABASE_KEY}`,
    'Content-Type': 'application/json',
    Prefer: 'return=representation',
  };

  try {
    if (req.method === 'GET') {
      const { id: queryId, search, limit = 200, sort, ...filters } = req.query;
      const id = queryId || urlId;

      if (id) {
        const singleRes = await fetch(`${baseUrl}?id=eq.${id}&limit=1`, { headers });
        const singleData = await singleRes.json();
        if (!singleRes.ok) return res.status(singleRes.status).json(singleData);
        return res.status(200).json(Array.isArray(singleData) ? singleData[0] : singleData);
      }

      let url = `${baseUrl}?limit=${limit}`;

      if (search && table === 'users') {
        url += `&email=ilike.*${encodeURIComponent(search)}*`;
      }

      if (sort) {
        url += `&order=${sort}`;
      }

      for (const [key, val] of Object.entries(filters)) {
        if (key === 'table') continue;
        url += `&${key}=${formatFilterValue(val)}`;
      }

      const listRes = await fetch(url, { headers });
      const listData = await listRes.json();
      if (!listRes.ok) return res.status(listRes.status).json(listData);

      const rows = Array.isArray(listData) ? listData : [listData];
      return res.status(200).json({ data: rows, total: rows.length });
    }

    if (req.method === 'POST') {
      let body = req.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch { body = {}; }
      }

      const createRes = await fetch(baseUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
      });
      const createData = await createRes.json();
      if (!createRes.ok) return res.status(createRes.status).json(createData);
      return res.status(201).json(Array.isArray(createData) ? createData[0] : createData);
    }

    if (req.method === 'PATCH' || req.method === 'PUT') {
      const id = req.query.id || urlId;
      if (!id) return res.status(400).json({ error: `ID obrigatório para ${req.method}` });

      let body = req.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch { body = {}; }
      }

      const updateRes = await fetch(`${baseUrl}?id=eq.${id}`, {
        method: req.method,
        headers,
        body: JSON.stringify(body),
      });
      const updateData = await updateRes.json();
      if (!updateRes.ok) return res.status(updateRes.status).json(updateData);
      return res.status(200).json(Array.isArray(updateData) ? updateData[0] : updateData);
    }

    if (req.method === 'DELETE') {
      const id = req.query.id || urlId;
      if (!id) return res.status(400).json({ error: 'ID obrigatório para DELETE' });

      const deleteRes = await fetch(`${baseUrl}?id=eq.${id}`, {
        method: 'DELETE',
        headers,
      });
      if (!deleteRes.ok) {
        const deleteData = await deleteRes.json();
        return res.status(deleteRes.status).json(deleteData);
      }
      return res.status(204).end();
    }

    return res.status(405).json({ error: 'Método não permitido' });
  } catch (err) {
    console.error(`[tables/${table}] Erro interno:`, err);
    return res.status(500).json({ error: `Erro Supabase: ${err?.message || String(err)}` });
  }
}
